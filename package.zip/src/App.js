import React, { useState, useEffect } from "react";
import { Table } from "react-bootstrap";
import { CSSTransition, TransitionGroup } from "react-transition-group";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function App() {
  const [columns, setColumns] = useState([]);
  const [data, setData] = useState([]);

  useEffect(() => {
    // Generate 37 columns
    const generatedColumns = Array.from({ length: 37 }, (_, index) => ({
      id: `column${index + 1}`,
      title: `Column ${index + 1}`,
      sticky: index < 5 || index >= 32, // Set the first 5 and last 5 columns as sticky
    }));
    setColumns(generatedColumns);

    // Generate sample data
    const generatedData = Array.from({ length: 1000 }, (_, index) => ({
      id: `row${index + 1}`,
      ...generateDataForColumns(generatedColumns),
    }));
    setData(generatedData);
  }, []);

  const generateDataForColumns = (cols) => {
    return cols.reduce((acc, col) => {
      return { ...acc, [col.id]: `Value for ${col.id}` };
    }, {});
  };

  const handleDragStart = (e, columnIndex) => {
    e.dataTransfer.setData("text/plain", columnIndex);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetIndex) => {
    const sourceIndex = e.dataTransfer.getData("text/plain");
    const updatedColumns = [...columns];
    const removed = updatedColumns.splice(sourceIndex, 1)[0];
    updatedColumns.splice(targetIndex, 0, removed);
    setColumns(updatedColumns);
  };

  return (
    <div className="App">
      <div className="table-container">
        <Table striped bordered hover>
          <thead>
            <tr>
              <TransitionGroup component={null}>
                {columns.map((column, index) => (
                  <CSSTransition
                    key={column.id}
                    classNames="column"
                    timeout={300}
                  >
                    <th
                      className={column.sticky ? "sticky-column" : ""}
                      draggable
                      onDragStart={(e) => handleDragStart(e, index)}
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, index)}
                    >
                      {column.title}
                    </th>
                  </CSSTransition>
                ))}
              </TransitionGroup>
            </tr>
          </thead>
          <tbody>
            {data.map((row, rowIndex) => (
              <tr key={row.id}>
                {columns.map((column, columnIndex) => (
                  <td
                    key={column.id}
                    className={
                      (column.sticky ? "sticky-column " : "") +
                      (rowIndex < 5 ? "sticky-row " : "")
                    }
                  >
                    {row[column.id]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default App;
