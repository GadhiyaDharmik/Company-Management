// import { del, get, post, put } from '../../searvices/webApi';

// const adddepartmentAPI = (data) => post("department", data);
// const getDepartment=(params)=> get(`department?page=${params?.page}&size=${params?.size}&search=${params?.search}`)
// const deletedepartmentAPI=(id)=>del(`department/${id}`)
// const updateDepartmentAPI=(data)=>put(`department/${data.id}`,data)
// // const searchDepartmentAPI = (data) => data.map(item => get(`department/${item.id}`));

// export { 
//   adddepartmentAPI, 
//   getDepartment,
//   updateDepartmentAPI,
//   deletedepartmentAPI,
//   // searchDepartmentAPI,
// };